# Vendorsnearyou
Online grocery and vegetable delivery portal that allows you to place order from nearby grocery stors as well as local vendors by taking your location 
